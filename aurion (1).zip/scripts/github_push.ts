import git from 'isomorphic-git';
import http from 'isomorphic-git/http/node';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function pushToGithub() {
  const dir = process.cwd();
  const remoteUrl = 'https://github.com/rooseve1t/aurion';
  const token = process.env.GITHUB_TOKEN;

  if (!token) {
    console.error('❌ GITHUB_TOKEN is missing. Please add it to the Secrets panel.');
    process.exit(1);
  }

  console.log(`🚀 Initializing git repository in ${dir}...`);

  try {
    // Initialize repo
    await git.init({ fs, dir });

    // Add all files
    console.log('📦 Adding files...');
    const files = await git.listFiles({ fs, dir });
    // We need to add files that are not ignored. isomorphic-git doesn't automatically handle .gitignore in addAll
    // But we can use git.status to filter
    
    const status = await git.statusMatrix({ fs, dir });
    const filesToAdd = status
      .filter(([filepath, head, workdir, stage]) => workdir === 1 && stage !== 1) // Modified or new
      .map(([filepath]) => filepath);

    for (const file of filesToAdd) {
      await git.add({ fs, dir, filepath: file });
    }

    // Commit
    console.log('💾 Committing changes...');
    await git.commit({
      fs,
      dir,
      message: 'AURION OS: System Sync to GitHub',
      author: {
        name: 'AURION OS',
        email: 'aurion@os.local'
      }
    });

    // Push
    console.log(`⬆️ Pushing to ${remoteUrl}...`);
    const pushResult = await git.push({
      fs,
      http,
      dir,
      remote: 'origin',
      url: remoteUrl,
      onAuth: () => ({ username: token }), // GitHub accepts token as username or password
    });

    if (pushResult.ok) {
      console.log('✅ Successfully pushed to GitHub!');
    } else {
      console.error('❌ Push failed:', pushResult);
    }
  } catch (error) {
    console.error('❌ Error during GitHub push:', error);
    process.exit(1);
  }
}

pushToGithub();
